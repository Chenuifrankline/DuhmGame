package codegenerator.templates;

import codegenerator.CodegenInterface;
import codegenerator.Template;
import org.eclipse.uml2.uml.StructuredClassifier;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;

@SuppressWarnings("all")
public class StructuredClassifierTemplate implements Template<StructuredClassifier> {
  @Override
  public String generateCode(final CodegenInterface it, final StructuredClassifier umlClassifier, final String context) {
    String _xblockexpression = null;
    {
      String att = "";
      final String generatedName = it.generate(umlClassifier, "name");
      for (int i = 0; (i < ((Object[])Conversions.unwrapArray(umlClassifier.getOwnedAttributes(), Object.class)).length); i++) {
        String _att = att;
        String _generate = it.generate(umlClassifier.getOwnedAttributes().get(i), "attribute");
        String _plus = ("\n\t" + _generate);
        att = (_att + _plus);
      }
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("typedef struct ");
      _builder.append(generatedName);
      _builder.append("_struct {");
      _builder.append(att);
      _builder.newLineIfNotEmpty();
      _builder.append("} ");
      _builder.append(generatedName);
      _builder.append(";");
      _builder.newLineIfNotEmpty();
      _xblockexpression = _builder.toString();
    }
    return _xblockexpression;
  }
}
