package codegenerator.templates;

import codegenerator.CodegenInterface;
import codegenerator.Template;
import com.google.common.collect.Iterables;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.uml2.uml.Dependency;
import org.eclipse.uml2.uml.Enumeration;
import org.eclipse.uml2.uml.NamedElement;
import org.eclipse.uml2.uml.Namespace;
import org.eclipse.uml2.uml.Operation;
import org.eclipse.uml2.uml.Parameter;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Type;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class ClassTemplate implements Template<org.eclipse.uml2.uml.Class> {
  @Override
  public String generateCode(final CodegenInterface it, final org.eclipse.uml2.uml.Class umlClass, final String context) {
    String _switchResult = null;
    if (context != null) {
      switch (context) {
        case "declaration":
          final String generatedName = it.generate(umlClass, "name");
          String _upperCase = generatedName.toUpperCase();
          String ifndef = (_upperCase + "_H");
          String _upperCase_1 = generatedName.toUpperCase();
          String define = (_upperCase_1 + "_H");
          String _generate = it.generate(umlClass, "typedefinition");
          String body = (_generate + "\n");
          String include = this.generateIncludes(it, umlClass);
          String voidString = "";
          EList<Operation> _ownedOperations = umlClass.getOwnedOperations();
          boolean _tripleNotEquals = (_ownedOperations != null);
          if (_tripleNotEquals) {
            EList<Operation> _ownedOperations_1 = umlClass.getOwnedOperations();
            for (final Operation operation : _ownedOperations_1) {
              String _body = body;
              String _generate_1 = it.generate(operation, context);
              String _plus = (_generate_1 + "\n\n");
              body = (_body + _plus);
            }
          }
          EList<Property> _ownedAttributes = umlClass.getOwnedAttributes();
          boolean _tripleNotEquals_1 = (_ownedAttributes != null);
          if (_tripleNotEquals_1) {
            include = this.generateIncludes(it, umlClass);
          }
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("#ifndef ");
          _builder.append(ifndef);
          _builder.newLineIfNotEmpty();
          _builder.append("#define ");
          _builder.append(define);
          _builder.newLineIfNotEmpty();
          _builder.newLine();
          _builder.append(include);
          _builder.newLineIfNotEmpty();
          _builder.append(body);
          _builder.newLineIfNotEmpty();
          _builder.append(voidString);
          _builder.newLineIfNotEmpty();
          _builder.append("#endif");
          _builder.newLine();
          return _builder.toString();
        case "implementation":
          String _xblockexpression = null;
          {
            String body_1 = "";
            String voidString_1 = "";
            for (int i = 0; (i < ((Object[])Conversions.unwrapArray(umlClass.getOwnedOperations(), Object.class)).length); i++) {
              int _length = ((Object[])Conversions.unwrapArray(umlClass.getOwnedOperations(), Object.class)).length;
              int _minus = (_length - 1);
              boolean _equals = (i == _minus);
              if (_equals) {
                String _body_1 = body_1;
                String _generate_2 = it.generate(umlClass.getOwnedOperations().get(i), context);
                String _plus_1 = (_generate_2 + "\n");
                body_1 = (_body_1 + _plus_1);
              } else {
                String _body_2 = body_1;
                String _generate_3 = it.generate(umlClass.getOwnedOperations().get(i), context);
                String _plus_2 = (_generate_3 + "\n\n");
                body_1 = (_body_2 + _plus_2);
              }
            }
            StringConcatenation _builder_1 = new StringConcatenation();
            _builder_1.append("#include \"");
            String _name = umlClass.getName();
            _builder_1.append(_name);
            _builder_1.append(".h\"");
            _builder_1.newLineIfNotEmpty();
            _builder_1.newLine();
            _builder_1.append(body_1);
            _builder_1.newLineIfNotEmpty();
            _builder_1.append(voidString_1);
            _builder_1.newLineIfNotEmpty();
            _xblockexpression = _builder_1.toString();
          }
          _switchResult = _xblockexpression;
          break;
        default:
          throw new UnsupportedOperationException(("Unsupported context: " + context));
      }
    } else {
      throw new UnsupportedOperationException(("Unsupported context: " + context));
    }
    return _switchResult;
  }

  /**
   * Die Methode sammelt alle erforderlichen Include-Anweisungen für die
   *  Header-Datei, basierend auf den Typen der Attribute,
   *  Parameter und Abhängigkeiten der Klasse
   */
  public String generateIncludes(final CodegenInterface it, final org.eclipse.uml2.uml.Class umlClass) {
    String _xblockexpression = null;
    {
      final HashSet<String> types = new HashSet<String>();
      EList<Property> _ownedAttributes = umlClass.getOwnedAttributes();
      for (final Property property : _ownedAttributes) {
        if (((property.getType() instanceof org.eclipse.uml2.uml.Class) || (property.getType() instanceof Enumeration))) {
          types.add(this.generatePath(it, umlClass, property.getType()));
        }
      }
      EList<Operation> _ownedOperations = umlClass.getOwnedOperations();
      for (final Operation operation : _ownedOperations) {
        EList<Parameter> _ownedParameters = operation.getOwnedParameters();
        for (final Parameter parameter : _ownedParameters) {
          if (((parameter.getType() instanceof org.eclipse.uml2.uml.Class) || (parameter.getType() instanceof Enumeration))) {
            types.add(this.generatePath(it, umlClass, parameter.getType()));
          }
        }
      }
      EList<Dependency> _clientDependencies = umlClass.getClientDependencies();
      for (final Dependency clients : _clientDependencies) {
        Iterable<Type> _filter = Iterables.<Type>filter(clients.getSuppliers(), Type.class);
        for (final Type supplier : _filter) {
          if (((supplier instanceof org.eclipse.uml2.uml.Class) || (supplier instanceof Enumeration))) {
            types.add(this.generatePath(it, umlClass, supplier));
          }
        }
      }
      StringConcatenation _builder = new StringConcatenation();
      {
        List<String> _sort = IterableExtensions.<String>sort(types);
        boolean _hasElements = false;
        for(final String type : _sort) {
          if (!_hasElements) {
            _hasElements = true;
          }
          _builder.append("#include \"");
          _builder.append(type);
          _builder.append("\"");
          _builder.newLineIfNotEmpty();
        }
        if (_hasElements) {
          _builder.append("\n");
        }
      }
      _xblockexpression = _builder.toString();
    }
    return _xblockexpression;
  }

  public String generatePath(final CodegenInterface it, final NamedElement from, final NamedElement to) {
    final Path fromPath = it.getPath(from, "declaration");
    final Path toPath = it.getPath(to, "declaration");
    Path _elvis = null;
    Path _parent = fromPath.getParent();
    Path _relativize = null;
    if (_parent!=null) {
      _relativize=_parent.relativize(toPath);
    }
    if (_relativize != null) {
      _elvis = _relativize;
    } else {
      _elvis = toPath;
    }
    final Path relPath = _elvis;
    return IterableExtensions.join(relPath, "/");
  }

  @Override
  public Path getPath(final org.eclipse.uml2.uml.Class umlClass, final String context) {
    LinkedList<String> path = new LinkedList<String>();
    if (context != null) {
      switch (context) {
        case "declaration":
          String _name = umlClass.getName();
          String _plus = (_name + ".h");
          path.addFirst(_plus);
          break;
        case "implementation":
          String _name_1 = umlClass.getName();
          String _plus_1 = (_name_1 + ".c");
          path.addFirst(_plus_1);
          break;
        default:
          return null;
      }
    } else {
      return null;
    }
    Namespace parent = umlClass.getNamespace();
    while ((null != parent)) {
      {
        path.addFirst(parent.getName());
        parent = parent.getNamespace();
      }
    }
    return Paths.get(IterableExtensions.<String>head(path), ((String[])Conversions.unwrapArray(IterableExtensions.<String>tail(path), String.class)));
  }
}
